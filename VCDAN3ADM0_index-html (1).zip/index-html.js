// Wait until the DOM is fully loaded
document.addEventListener("DOMContentLoaded", function() {
    // ===== Typing Effect for Header =====
    const typingText = document.querySelector(".typing-text");
    const fullText = typingText.textContent;
    typingText.textContent = "";
    let index = 0;

    function typeWriter() {
        if (index < fullText.length) {
            typingText.textContent += fullText.charAt(index);
            index++;
            setTimeout(typeWriter, 100); // Adjust typing speed (milliseconds)
        }
    }
    typeWriter();

    // ===== Reveal Animation on Scroll =====
    function reveal() {
        const reveals = document.querySelectorAll(".reveal");
        for (let i = 0; i < reveals.length; i++) {
            let windowHeight = window.innerHeight;
            let elementTop = reveals[i].getBoundingClientRect().top;
            let elementVisible = 150; // Adjust this threshold if needed
            if (elementTop < windowHeight - elementVisible) {
                reveals[i].classList.add("active");
            } else {
                reveals[i].classList.remove("active");
            }
        }
    }

    // Trigger reveal animation on scroll
    window.addEventListener("scroll", reveal);
    reveal(); // Run reveal once on page load
});